import { useCallback, useEffect, useMemo, useState } from "react";
import Board from "./Board";
import {
  MAX_PLIES,
  buildTrees,
  fenForPath,
  findGaps,
  getUsernames,
  lineLabel,
  nodeAt,
  saveUsernames,
  scoreClass,
} from "./openingsData";
import "./Openings.css";

function go(page, extra = {}) {
  window.dispatchEvent(new CustomEvent("qelvaris-navigate", { detail: { page, ...extra } }));
}

const pct = (score) => `${Math.round(score * 100)}%`;
const plural = (n) => `${n} game${n === 1 ? "" : "s"}`;

function moveLabel(ply, san) {
  const number = Math.ceil(ply / 2);
  return ply % 2 === 1 ? `${number}.${san}` : `${number}…${san}`;
}

function Column({ nodes, selected, onPick }) {
  return (
    <ul className="qo-col">
      {nodes.map((node) => {
        const cls = scoreClass(node);
        const size = 10 + Math.min(node.games, 20) * 0.9;
        return (
          <li key={node.san}>
            <button
              className={`qo-node qo-node--${cls} ${selected === node.san ? "is-selected" : ""}`}
              onClick={() => onPick(node.san)}
            >
              <span className={`qo-dot qo-dot--${cls}`} style={{ width: size, height: size }} />
              <span className="qo-node-main">
                <span className="qo-move">{moveLabel(node.ply, node.san)}</span>
                <span className="qo-meta">
                  {plural(node.games)}
                  {node.games >= 2 ? ` · ${pct(node.score)}` : ""}
                </span>
              </span>
            </button>
          </li>
        );
      })}
    </ul>
  );
}

function UsernameCard({ names, onSave, highlight }) {
  const [text, setText] = useState(names.join(", "));

  return (
    <section className={`qo-card ${highlight ? "qo-card--hl" : ""}`}>
      <div className="qo-eyebrow">Your usernames</div>
      <p className="qo-note">
        Tree banane ke liye pata hona chahiye ki har game mein aap White the ya Black. Apne Lichess / Chess.com naam daalo (comma se alag).
      </p>
      <div className="qo-form">
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="jaise: ravi_chess, ravi88" />
        <button className="qo-btn qo-btn--primary" onClick={() => onSave(text.split(",").map((s) => s.trim()).filter(Boolean))}>
          Save
        </button>
      </div>
    </section>
  );
}

export default function Openings() {
  const [data, setData] = useState(null);
  const [names, setNames] = useState([]);
  const [error, setError] = useState("");
  const [color, setColor] = useState("w");
  const [path, setPath] = useState([]);

  const load = useCallback(async () => {
    try {
      const [built, saved] = await Promise.all([buildTrees(), getUsernames()]);
      setData(built);
      setNames(saved);
    } catch (err) {
      console.error("Openings load failed:", err);
      setError("Openings load nahi ho payi. Page refresh karke dekho.");
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function onSaveNames(list) {
    await saveUsernames(list);
    setPath([]);
    await load();
  }

  const root = data?.trees[color];
  const selectedNode = useMemo(() => (root ? nodeAt(root, path) : null), [root, path]);
  const gaps = useMemo(() => (root ? findGaps(root) : []), [root]);

  if (error) return <div className="qo-page"><p className="qo-note">{error}</p></div>;
  if (!data) return <div className="qo-page"><p className="qo-note">Loading…</p></div>;

  const total = data.usedCount.w + data.usedCount.b;

  // Columns: har level par selected node ke bacche
  const columns = [];
  let node = root;
  for (let depth = 0; depth <= path.length && node && depth < MAX_PLIES; depth += 1) {
    if (node.children.length) columns.push({ nodes: node.children, selected: path[depth] });
    node = node.children.find((c) => c.san === path[depth]);
  }

  return (
    <div className="qo-page">
      <div className="qo-head">
        <h2 className="qo-title">Openings</h2>
        <div className="qo-tabs" role="tablist">
          {[["w", "As White"], ["b", "As Black"]].map(([id, label]) => (
            <button
              key={id}
              role="tab"
              aria-selected={color === id}
              className={`qo-tab ${color === id ? "is-active" : ""}`}
              onClick={() => {
                setColor(id);
                setPath([]);
              }}
            >
              {label} <span className="qo-n">{data.usedCount[id]}</span>
            </button>
          ))}
        </div>
      </div>

      {total === 0 && (
        <UsernameCard names={names} onSave={onSaveNames} highlight />
      )}

      {total > 0 && (
        <div className="qo-layout">
          <section className="qo-card">
            <div className="qo-eyebrow">Your opening tree · {color === "w" ? "as White" : "as Black"}</div>

            {root.children.length === 0 ? (
              <p className="qo-note">Is rang mein abhi koi game nahi.</p>
            ) : (
              <div className="qo-cols">
                {columns.map((col, i) => (
                  <Column
                    key={i}
                    nodes={col.nodes}
                    selected={col.selected}
                    onPick={(san) => setPath([...path.slice(0, i), san])}
                  />
                ))}
              </div>
            )}

            <div className="qo-legend">
              <span><i className="qo-dot qo-dot--good" /> 60% or more</span>
              <span><i className="qo-dot qo-dot--mid" /> 45 to 59%</span>
              <span><i className="qo-dot qo-dot--bad" /> under 45%</span>
              <span><i className="qo-dot qo-dot--few" /> too few games</span>
              <span>Circle size = games played</span>
            </div>
          </section>

          <aside className="qo-side">
            <section className="qo-card">
              <div className="qo-eyebrow">Selected line</div>
              {selectedNode && path.length > 0 ? (
                <>
                  <div className="qo-line">{lineLabel(path)}</div>
                  <div className="qo-board">
                    <Board fen={fenForPath(path)} flipped={color === "b"} showCoords={false} />
                  </div>
                  <div className="qo-stats">
                    <div><strong>{selectedNode.games}</strong><span>games</span></div>
                    <div><strong>{selectedNode.games >= 2 ? pct(selectedNode.score) : "–"}</strong><span>score</span></div>
                  </div>
                  <button className="qo-btn qo-btn--primary" onClick={() => go("Leak Lab", { line: path, color })}>
                    Practise this line
                  </button>
                </>
              ) : (
                <p className="qo-note">Tree mein koi chaal chuno.</p>
              )}
            </section>

            <section className="qo-card">
              <div className="qo-eyebrow">Gaps worth fixing</div>
              {gaps.length === 0 ? (
                <p className="qo-note">Koi kamzor line nahi mili (3+ games aur 45% se neeche wali). Ya abhi games kam hain.</p>
              ) : (
                <ul className="qo-gaps">
                  {gaps.map(({ path: p, node: n }) => (
                    <li key={p.join(" ")}>
                      <button className="qo-gap" onClick={() => setPath(p)}>
                        <span>{lineLabel(p)}</span>
                        <span className="qo-meta">{pct(n.score)} · {plural(n.games)}</span>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </aside>
        </div>
      )}

      {total > 0 && (data.noColor > 0 || data.noMoves > 0) && (
        <p className="qo-note qo-foot">
          {data.noColor > 0 && `${data.noColor} games mein aapka rang pata nahi chala (username check karo). `}
          {data.noMoves > 0 && `${data.noMoves} games mein moves nahi mile.`}
        </p>
      )}

      {total > 0 && <UsernameCard names={names} onSave={onSaveNames} />}
    </div>
  );
}
